# Relational height populations and arithmetic visibility

*First focused manuscript, version 0.2.0. Release revision of 18 October 2026 after a claim-by-claim audit (roadmap push P35). Each substantive claim is mapped to its proof, computation or formal artifact in `docs/papers/visibility_claims.md`. The companion structural paper is `docs/papers/locality.md`.*

## Abstract

We study nonnegative integer heights on a finite graph, counted jointly by total height and quadratic edge energy. Removing a common translation gives canonical minimum-zero profiles. An additional span mark separates binary cuts from nested height configurations. We give explicit seven-vertex examples in which equal Laplacian characteristic polynomials, or equal complete binary cut-volume censuses, coexist with unequal height coefficients. The first differences occur at total heights two and three. For both pairs, the unmarked local coefficient tables through total height four, equality below the first difference, the first-difference polynomial and its stated factorization are checked by the Lean 4 kernel against a semantic definition of the coefficients. The source-graph and JSON transcription boundaries are recorded separately from the kernel-checked statements. A third comparison, between the cube and the eight-vertex Möbius ladder, delays the first difference to total height four; it is checked by exact software replay only. For a fixed energy weight q in the closed unit interval, we prove the following. If the first difference occurs at total height r, it fixes the exponent of a zeta factor in the ratio of the associated prime products, and hence the power singularity at s=1/r. The positive-real comparison is also kernel-checked over Mathlib's real numbers and actual Riemann zeta function, including both exact exponents at q=1/2. For those two seven-vertex pairs, the regular factor at s=1/r is enclosed in explicit rigorous intervals. The examples come with standard-library exact software, independent finite replay, and an exhaustive census of connected graphs through six vertices. General reconstruction for the original scalar-height series and historical priority are unclaimed; a companion paper proves unbounded delayed visibility and sharp reconstruction within a specific graph class.

## 1. Question and background

A graph parameter can retain many numerical facts while forgetting the correspondence between the configurations that produced them. The binary cut-volume census is a useful example. It counts vertex subsets jointly by cardinality and boundary size, so equality of this polynomial is stronger than equality of a single energy moment. Nevertheless, it does not retain which subsets are nested or which edges cross two of their boundaries simultaneously. Integer heights provide a direct way to observe those relationships.

The ingredients have established antecedents. Integral cut lattices organize graph gradients modulo constants [BHN1997]. Bivariate Ising polynomials organize binary configurations [AM2009]. Integer-valued Gaussian models on lattices use the same squared nearest-neighbour energy [BPR2024]. Formal Euler transforms reorganize coefficient data into cyclotomic factors [Moree2005]. We use these ingredients with explicit marks and a restricted inverse question. The paper does not claim a new origin for the individual ingredients. Nor does it claim that the proposed scalar-height observations determine every graph. No completed priority search is claimed.

There are two logically distinct constructions. First, a local generating function records a finite graph's integer heights. Second, an Euler product attaches that same local function to every rational prime. The first determines graph-information content. The second supplies an arithmetic organization and a precise comparison of singularities. Keeping this distinction visible prevents a prime product from being credited with information that it merely reencodes.

Results labeled SNG-… refer to full proofs in the [project monograph](../MONOGRAPH.md). The proofs given here are complete for the statements as displayed. Finite Lean theorem names refer to the core Lean 4.12.0 package in `formal/`. The real-analytic theorems are in `formal-analysis/`, using the pinned Mathlib v4.12.0 dependency and the same kernel.

The closest objects can be compared directly, rather than by terminology. Under spins \(\sigma_v\in\{-1,1\}\), let S be the negative-spin set. Then \(\sum_v\sigma_v=k-2|S|\) and \(\sum_{uv\in E}\sigma_u\sigma_v=|E|-2|\partial S|\). Thus the uniform-coupling Ising partition function with field is \(e^{\beta|E|+hk}I_G(e^{-2h},e^{-2\beta})\) in our cut convention. Equality of the binary census is equality of this particular binary-state observation, not an unknown new form of Ising equivalence. The volume-three example proves only that its two specified graphs separate when integer heights are allowed.

For a connected graph, the gradient map sends integer heights modulo constants to its integral cut lattice, and \(E_G\) is the squared gradient norm. This is the established framework of [BHN1997]. Our common minimum-zero representative and total-height and span marks carry additional chamber information; we do not identify the resulting series with a theta series that forgets these marks. In [BPR2024] the integer-valued Gaussian model is studied on lattices, with a high-temperature scaling question. Its energy is a direct antecedent, while the present finite graph invariant, marked exact populations and first-discrepancy comparison are the claims requiring the proofs below. Finally [Moree2005] supplies formal cyclotomic-transform context; it does not substitute for the real analytic estimates in Theorem 3. The primary-source comparison and checked bibliographic records are retained in `docs/papers/literature_comparison.md`; no historical-priority conclusion is drawn from that bounded search.

## 2. Local populations and their marks

Let G be a finite connected simple loopless graph on vertices \(0,\ldots,k-1\), with \(k\ge2\). Write \(d_i\) for its degrees and \(A_{ij}\) for its adjacency matrix. Connectedness is used only in Section 5 and in the certified enclosures of Section 4. Propositions 1 and 2 and Theorem 3 hold without it. For a nonnegative integer vector a, put

\[
 |a|=\sum_i a_i,\qquad
 E_G(a)=\sum_{\{i,j\}\in E(G)}(a_i-a_j)^2.
\]

The unnormalized series and the fully marked normalized series are

\[
 L_G(x,q)=\sum_{a\ge0}x^{|a|}q^{E_G(a)},\qquad
 \mathcal B_G(x,q,z)=\sum_{\min a=0}x^{|a|}q^{E_G(a)}z^{\max a}.
\]

Every coefficient of x is a finite polynomial in q, because there are only \(\binom{m+k-1}{k-1}\) nonnegative vectors of total height m (SNG-F01). Hence these definitions are formal before any analytic parameter is chosen. Counts are of original labeled assignments; no quotient by graph automorphisms is taken. For 0 at most q at most one and absolute value of x below one, comparison with \((1-|x|)^{-k}\) also gives analytic convergence.

**Proposition 1 (translation normalization; SNG-F02).** With \(B_G(x,q)=\mathcal B_G(x,q,1)\),

\[
 L_G(x,q)=\frac{B_G(x,q)}{1-x^k}.
\]

**Proof.** Every nonnegative vector has the unique form \(a=b+t\mathbf1\), where \(t=\min a\) and \(\min b=0\). Edge differences, and hence energy, are unchanged. Total height increases by kt. Summing the common translation gives the geometric factor. This is a formal identity with no convergence assumption. \(\square\)

The coefficientwise form of Proposition 1 is kernel-checked for arbitrary edge lists, including disconnected graphs, as `allCount_eq_shiftSum` and `allCount_rec` (`formal/Singularity/Normalization.lean`). The span-marked identity, with z retained, is not formalized.

The span mark records a genuine distinction. The binary cut polynomial

\[
 I_G(x,q)=\sum_{S\subseteq V(G)}x^{|S|}q^{|\partial S|}
\]

satisfies \(I_G=1+x^k+[z]\mathcal B_G\) (SNG-F11). Thus the full marked series contains the binary census explicitly. The specialization z=1 merges spans; a general recovery theorem for the binary sector from that specialization is not established here.

**Proposition 2 (nested-boundary energy; SNG-F09, SNG-F10).** A normalized vector of span h is equivalent to a chain of nonempty proper sets

\[
 S_h\subseteq\cdots\subseteq S_1,\qquad
 a=\sum_{t=1}^h\mathbf1_{S_t}.
\]

Repeated sets are permitted. If \(e(U,W)\) counts edges between disjoint sets, then

\[
 |a|=\sum_t|S_t|,\qquad
 E_G(a)=\sum_t|\partial S_t|
       +2\sum_{r<t}e(S_t,V\setminus S_r).
\]

**Proof.** Take \(S_t=\{i:a_i\ge t\}\). Each coordinate is recovered by counting its occupied thresholds, proving the bijection and total-height identity. On an edge, every nonzero threshold difference has the same sign. Expanding the square of their sum gives the individual threshold crossings and twice every pair of simultaneous crossings. For \(r<t\), simultaneous crossing means that one endpoint lies in \(S_t\) and the other outside \(S_r\). Summing edges proves the formula. \(\square\)

The threshold reconstruction, the volume identity and the energy identity are kernel-checked for every edge list and every profile as `reconstruct`, `vol_eq_levels` and `energy_nested`. Nestedness and properness of the threshold sets are checked as `thr_nested` and `thr_proper_of_minZero`, and the span count as `span_eq` (`formal/Singularity/Thresholds.lean`). The converse direction of the bijection, from an arbitrary chain to a profile, is proved above but is not stated in Lean.

For two levels, this becomes \(E(\mathbf1_S+\mathbf1_T)=|\partial S|+|\partial T|+2e(S,V\setminus T)\), for nonempty S contained in proper T, allowing equality. The final term explains why a distribution of isolated cuts can miss the multilevel population.

## 3. Finite visibility and reference examples

Put \(\ell_{G,m}(q)=[x^m]L_G(x,q)\). Splitting weak compositions by their multiplicity patterns gives (SNG-F14)

\[
 \ell_{G,1}=\sum_iq^{d_i},\qquad
 \ell_{G,2}=\sum_iq^{4d_i}+\sum_{i<j}q^{d_i+d_j-2A_{ij}},
\]

\[
 \begin{aligned}
 \ell_{G,3}={}&\sum_iq^{9d_i}
 +\sum_{i\ne j}q^{4d_i+d_j-4A_{ij}}\\
 &+\sum_{i<j<t}q^{d_i+d_j+d_t-2(A_{ij}+A_{it}+A_{jt})}.
 \end{aligned}
\]

These formulas also delimit the meaning of a small-depth witness. Volume one observes degrees. With degrees fixed, volume two observes the edge degree-sum polynomial \(M_G(q)=\sum_{ij\in E}q^{d_i+d_j}\), since then \(\ell_{G,2}-\ell_{H,2}=(q^{-2}-1)(M_G-M_H)\). The current volume-three witness separates an aggregated binary census by an ordered two-vertex height pattern. It is not a claim that the graph energy contains a new three-body interaction.

All reference inputs are explicit. On vertices \(0,\ldots,6\), the first pair has edge sets

\[
 \begin{aligned}
 E(G_2)&=\{01,02,03,04,12,35,36\},\\
 E(H_2)&=\{01,02,03,04,15,16,56\}.
 \end{aligned}
\]

Their degree multisets and Laplacian characteristic polynomials agree. The latter, computed exactly in integer arithmetic, is

\[
 t^7-14t^6+73t^5-178t^4+209t^3-112t^2+21t.
\]

The unique degree-four vertex lies in a triangle in the first graph and not the second, so they are nonisomorphic (SNG-E001). Direct coefficient enumeration gives the first difference

\[
 \ell_{G_2,2}-\ell_{H_2,2}=2q^2(1-q)^3(1+q)=2q^2(1-q)^2(1-q^2).
\]

Its source is elementary: the degree-sum polynomials differ, \(M_{G_2}-M_{H_2}=2q^4(1-q)^2\). The pair therefore separates the height population from the Laplacian spectrum through degree mixing, not through a higher-order relation.

The second pair has edge sets

\[
 \begin{aligned}
 E(G_3)&=\{03,04,06,12,13,23,24,35\},\\
 E(H_3)&=\{01,04,06,15,16,26,36,45\}.
 \end{aligned}
\]

Its graphs have the same complete binary cut-volume polynomial: enumeration of all 128 subsets of each graph agrees at every pair of subset size and boundary size. Their unique degree-four vertices have respectively one and two leaf neighbors, proving nonisomorphism (SNG-E002). The local coefficients agree through volume two, while

\[
 \ell_{G_3,3}-\ell_{H_3,3}
 =q^3(1-q)(1-q^3)^2(1-q^4)^2.
\]

This entire discrepancy occurs in span two. Span one agrees by the binary-census equality, and span three agrees by the equal degree multisets. The degree-sum polynomials agree, which explains agreement at volume two. The finer joint degree table of the edges differs, and the unequal-height sector weights endpoint degrees through \(4d_i+d_j\). Both differences are strictly positive on the open interval between zero and one, as their factorizations show.

The elementary invariants shared by each pair are summarized below. The data are in `results/exact_examples.json`.

| Pair | Order | Degree multiset | Laplacian char. polynomial | Binary cut census | Edge degree-sum polynomial | First difference: volume, span |
|---|---:|---|---|---|---|---|
| \(G_2,H_2\) | 7 | equal | equal | different | different | 2, span 1 |
| \(G_3,H_3\) | 7 | equal | different | equal | equal | 3, span 2 |
| cube, Möbius ladder | 8 | equal (3-regular) | different | different | equal (regular) | 4, span 1 |

**Kernel-checked scope.** For the first two pairs, the decisive coefficients are checked in Lean 4.12.0 (core library only, no project axioms) by kernel evaluation of the released certificates `results/certificates/spectral.json` and `results/certificates/binary_census.json`. Write X for `spectral` or `binary` in namespace `Singularity.Cert`. The following hold for the stated edge lists on seven vertices.

- `X_local` and `XCmp_local`: every coefficient \([x^Vq^e]L\) of each graph, for all V at most 4 and all integers e, equals the transcribed table. The coefficient is defined semantically by `allCount`, as a count of all length-7 profiles of volume V and energy e.
- `X_normalized`: the minimum-zero coefficients \([x^Vq^e]B\) of the certificate graph \(G_2\), respectively \(G_3\), through volume 4. This follows from P07 because these volumes are below 7.
- `X_agree_below`: the two graphs agree at every volume below the first difference.
- `X_first_difference`, `X_factorization` and `X_discrepancy`: the first-difference polynomial is the displayed one, it equals the expansion of the factorization \(2q^2(1-q)^2(1-q^2)\), respectively \(q^3(1-q)(1-q^3)^2(1-q^4)^2\), and it is nonzero.

Rejection theorems show that one changed edge or one changed decisive coefficient is refused. The trusted boundary is the transcription script `formal/tools/gen_certificates.py`, which copies the JSON numbers into Lean literals and records the input SHA-256 digests. These are `379d5c47…ec6b2` for `spectral.json` and `e654012d…e4b2` for `binary_census.json`; full digests are in `formal/README.md`. The script's `--check` mode detects a stale transcription.

The kernel does not check the span-marked rows, which include the span-two localization above. It also does not check the Euler exponents, the binary cut census, the Laplacian polynomials, nonisomorphism, simplicity of the edge lists, or anything about the Python implementation. Those rest on exact software replay, on two independent enumerators, and on the short arguments given here. The package builds from a clean download of the pinned Lean release in the project's continuous integration, which also audits that the listed theorems depend only on Lean's standard axioms; the build command and theorem list are in `formal/README.md`.

A third pair, the three-dimensional cube and the eight-vertex Möbius ladder, consists of triangle-free cubic graphs. They are nonisomorphic because the cube is bipartite and the ladder contains a five-cycle. Their local coefficients agree through volume three and first differ at volume four by \(2q^4(1-q^2)^4\). That difference lies in span one, the binary sector. The example illustrates delayed visibility after matching regular low-order data. It does not duplicate the binary-census equality of the second pair. Its coefficients are confirmed by the independent software replay of `results/certificates/regular_cube_mobius.json`. They are not kernel-checked.

## 4. Arithmetic assembly and the comparison theorem

For a positive integer \(n\), let \(v_p(n)\) be its \(p\)-adic valuation. Define

\[
 \mathcal E_G(n_1,\ldots,n_k)
 =\sum_pE_G(v_p(n_1),\ldots,v_p(n_k)),
\]

\[
 Z_G(s,q)=\sum_{n_1,\ldots,n_k\ge1}
 \frac{q^{\mathcal E_G(\mathbf n)}}{(n_1\cdots n_k)^s}.
\]

For fixed q in the closed unit interval and real part of s greater than one, absolute convergence and unique factorization give \(Z_G(s,q)=\prod_pL_G(p^{-s},q)\) (SNG-A01). The construction is multiplicative across primes, while each prime's local factor retains the graph interaction among its exponent coordinates.

**Theorem 3 (first-discrepancy visibility; SNG-A11).** Fix q in the closed interval [0,1]. Suppose two graphs with the same number of vertices satisfy \(\ell_{G,m}(q)=\ell_{H,m}(q)\) for m below r, and \(\delta=\ell_{G,r}(q)-\ell_{H,r}(q)\ne0\). Then their ratio Euler product converges for real s greater than 1/r and equals

\[
 R_{G,H}(s,q)=\zeta(rs)^\delta K_{G,H}(s,q),
\]

where K has a finite positive limit at s=1/r and is holomorphic and nonzero in a complex neighborhood of that point. Consequently

\[
 R_{G,H}(s,q)\sim K_{G,H}(1/r,q)(rs-1)^{-\delta}
 \quad(s\downarrow1/r).
\]

**Proof.** Constant terms are one, so cancellation of the lower local coefficients gives \(L_G/L_H=1+\delta x^r+O(x^{r+1})\). The ratio Euler product therefore has an absolutely summable logarithm for real s greater than 1/r. Every local factor is positive there. Multiplication by \((1-x^r)^\delta\) removes the first discrepancy, yielding \(1+O(x^{r+1})\). Thus

\[
 K_{G,H}(s,q)=\prod_p(1-p^{-rs})^\delta
              \frac{L_G(p^{-s},q)}{L_H(p^{-s},q)}
\]

converges for real s greater than 1/(r+1). Near s=1/r, finitely many small-prime factors are nonzero by positivity and continuity; the remaining tail has a normally convergent logarithm. This proves the local complex statement. The zeta Euler product proves the factorization on the right of 1/r, and \(\zeta(1+t)\sim1/t\) gives the asymptotic. \(\square\)

The hypothesis concerns values at the chosen q. A polynomial discrepancy can vanish at an endpoint or at an interior root, which changes the first visible volume at that parameter. For the three reference pairs the polynomial differences are positive on 0<q<1, so the theorem applies there with r=2, 3 and 4. At q=1/2 the exponents are δ=3/32 at s=1/2, δ=11025/262144 at s=1/3, and δ=81/2048 at s=1/4 for the cube comparison. These are exact rational evaluations of the displayed differences. Nonintegral exponents give power or branch singularities, not ordinary poles. The quotient is initially a quotient of convergent positive series on s>1; its ratio Euler product supplies the extension used in the theorem. No global meromorphic-continuation claim follows. The positive-real part of Theorem 3 is kernel-checked by `SingularityAnalysis.graph_visibility` in `formal-analysis/SingularityAnalysis/SpectralVisibility.lean`. Its hypotheses are the numerical range of q, a positive depth r and finite agreement of the actual graph coefficients below r. The local logarithmic estimates, prime-product convergence, nonvanishing at the boundary and the zeta residue limit are proved in the imported chain. The local-complex holomorphy and branch-continuation statements remain ordinary mathematical proofs.

**Certified regular factors.** The constant \(K_{G,H}(1/r,1/2)\) has been enclosed rigorously for the two seven-vertex pairs (SNG-F38, `results/certified_k.json`). The enclosure assumes that both graphs are connected, q is rational in (0,1) and s=a/b is rational with (r+1)s>1. It keeps all primes up to a cutoff \(P=N^b\) exactly and bounds the omitted primes by an explicit constant times \(P^{1-(r+1)s}/((r+1)s-1)\). Truncated heights are bounded by a quadratic tail estimate (SNG-F39). The computation uses 256-bit fixed-point arithmetic with outward rounding and series enclosures of the logarithms. The retained intervals, rounded outward from their exact dyadic endpoints, are as follows.

| Pair | \(s\) | Primes kept | Enclosure of \(K(s,1/2)\) |
|---|---|---:|---|
| \(G_2,H_2\), \(r=2\), \(\delta=3/32\) | \(1/2\) | 1229 (\(p\le10^4\)) | \([0.84973,\,0.85750]\) |
| \(G_2,H_2\) | \(3/5\) | 985 (\(p\le6^5\)) | \([0.89931,\,0.89971]\) |
| \(G_2,H_2\) | \(1\) | 168 (\(p\le10^3\)) | \([0.9678188,\,0.9678191]\) |
| \(G_3,H_3\), \(r=3\), \(\delta=11025/262144\) | \(1/3\) | 2961 (\(p\le30^3\)) | \([0.90084,\,0.94230]\) |

Thus \(R_{G_2,H_2}(s,1/2)\sim C_2(2s-1)^{-3/32}\) with \(C_2\in[0.84973,0.85750]\). Likewise \(R_{G_3,H_3}(s,1/2)\sim C_3(3s-1)^{-11025/262144}\) with \(C_3\in[0.90084,0.94230]\). The exponents come from Theorem 3 and the exact coefficients; they are not fitted. The binary interval is wide because the omitted-prime bound decays only like \(P^{-1/3}\) at s=1/3. These are computer-assisted interval computations in Python. They are not kernel-checked. No enclosure has been computed for the cube comparison.

## 5. Synchronization and its singular limit

Connectedness implies zero energy exactly at constant heights. Hence \(Z_G(s,0)=\zeta(ks)\), whereas \(Z_G(s,1)=\zeta(s)^k\) (SNG-A04). More generally, the first local coefficient is \(\alpha_G(q)=\sum_iq^{d_i}\). For fixed q in [0,1], removal of the linear Euler term gives (SNG-A09)

\[
 Z_G(s,q)=\zeta(s)^{\alpha_G(q)}H_G(s,q),
\]

initially for real part of s above one, with H holomorphic for real part of s above 1/2 and positive and nonzero near real s=1. Every fixed positive q therefore restores an s=1 divergence, while exact synchronization q=0 leaves the finite value \(\zeta(k)\) there. The order of these two limits matters.

Let d be minimum degree and b the number of vertices attaining it. Suppose q tends to zero and real s tends down to one, along sequences, with \(q^d\log(1/(s-1))\to c<\infty\). Then (SNG-A16)

\[
 \frac{Z_G(s,q)}{\zeta(ks)}\longrightarrow e^{bc}.
\]

To justify this limit, use translation-normalized local factors and subtract their common linear term. For real s at least one, each such logarithm is bounded by an explicit constant times \(q^\lambda p^{-2s}\), where λ is the edge connectivity. The bound comes from the weak-composition coefficient count and the fact that every nonzero minimum-zero profile has energy at least λ (SNG-A15). Summing over primes, the normalized product tends to one as q tends to zero, uniformly in s. Finally \(\alpha_G(q)=bq^d+O(q^{d+1})\) and \(\log\zeta(s)=\log(1/(s-1))+O(s-1)\) supply the exponential limit. This argument describes a boundary layer in the declared real domain, independently of any global continuation question.

The first positive energy has a separate combinatorial interpretation. Integer coarea bounds energy below by the sum of threshold cut sizes, hence by λ times span. Equality at the minimum positive energy forces a binary minimum-cut indicator (SNG-A05). Consequently, initially for real part of s above one, the coefficient of \(q^\lambda\) in \(\log(Z_G/\zeta(ks))\) is the sum of prime-zeta functions \(\sum_{|\partial S|=\lambda}P(|S|s)\), counting both cut orientations (SNG-A06). This links cut side sizes to an analytic coefficient without claiming that minimum cuts identify the whole graph.

## 6. Computational and formal scope

The released computational core uses integer and rational arithmetic and the Python standard library. It supplies weak-composition counts, marked sectors, exact Laplacian characteristic polynomials, formal Euler exponents with independent recomposition, constrained original-label rank and unrank, forest message passing, root-of-unity residue numerators, weighted hard contraction and primitive-profile inversion. A finite certificate records a graph source, coefficient range and declared comparison. Replay parses it strictly and recomputes all coefficients by two routes that do not reuse the builder's enumerator: stars-and-bars compositions and level chains. It also checks the normalization and threshold identities. `PYTHONPATH=src python scripts/reproduce.py --check` replays the four retained certificates and the three comparison pairs. These are software-level exact checks relative to the Python interpreter.

The core Lean package in `formal/` kernel-checks the coefficientwise normalization identity of Proposition 1, the nested energy identity of Proposition 2, the decisive unmarked coefficient tables of the first two pairs, and finite first-discrepancy cancellation. A first coefficient discrepancy at volume r gives the quotient \(1+\delta x^r\) modulo \(x^{r+1}\), and the binomial factor cancels it. The concrete quotients are obtained from the P33 coefficient theorems rather than assumed data.

The separate package `formal-analysis/` closes the positive-real analytic chain over Mathlib's actual real numbers, real powers, topology, Riemann zeta function and infinite products. `SingularityAnalysis.visibility_of_coefficients` derives the comparison from nonnegative unit-constant coefficients of polynomial growth and finite agreement below r. The local logarithmic remainder estimates, prime summability, convergence and positivity of the normalized product, its continuity at the boundary, the zeta Euler product and its residue limit are discharged within the compiling theorem chain. `SingularityAnalysis.graph_visibility` applies it to the actual graph height coefficients for q in [0,1] and identifies the continued ratio with the quotient of the two original prime products on s>1. No `RealFacts` structure or unproved analytic premise packet remains in that theorem.

For the two reference pairs, `SingularityAnalysis.spectral_visibility` and `SingularityAnalysis.binary_visibility` import the certified finite coefficient facts. The specialized theorems `SingularityAnalysis.spectral_visibility_half` and `SingularityAnalysis.binary_visibility_half` prove the positive-real boundary limits with exponents 3/32 and 11025/262144, respectively. These theorems include convergence of raw and regularized products, the zeta factorization, positivity of the regular factor and the right-hand normalized limit. Their assumptions and standard-axiom dependencies are audited in the released formal build. The interval endpoints, local-complex continuation, synchronization results of Section 5, span-marked generating functions, graph nonisomorphism and Python implementation are outside this real-analytic formal scope.

An exhaustive enumeration covers all labeled simple graphs on one to six vertices, 26,704 of which are connected on six vertices. Connected graphs were grouped into isomorphism classes by an exact minimal adjacency code over degree-preserving relabelings. This yields respectively 1, 1, 2, 6, 21 and 112 classes (`results/small_census.json`, `scripts/census.py --max-order 6 --max-volume 6`). For order six, exact polynomial local coefficients through volumes one, two and three distinguish respectively 68, 100 and 112 classes. In this population the binary cut census also separates all classes, so a connected nonisomorphic pair with equal binary census, such as the second pair, needs at least seven vertices. This is a complete finite census with an explicit generation boundary. It does not imply completeness at larger orders. In particular, the seven- and eight-vertex examples illustrate why visibility depth must remain part of the specification.

## 7. Open structural questions

The main inverse problem asks whether the original fixed scalar-height observations identify a graph in a declared class. A negative answer should describe a transformation or an exact pair preserving all heights, rather than merely a long agreeing prefix. Unbounded delayed visibility is now proved in explicit families (SNG-F36 and SNG-F56); it is no longer an open existence question. The companion paper `docs/papers/locality.md` gives the cycle collision family, its invariant leading discrepancy under every fixed closing context, and sharp reconstruction of simple 2-regular interiors at budget \(\lfloor n/2\rfloor\). Neither that class theorem nor a finite census proves general completeness of the fixed-pinning series. The project's moment-enriched series has a separate completeness theorem (SNG-F58), with a much larger separating-volume argument, outside the scope of this article. If every vertex receives an independent variable, labeled adjacency is recovered already from the one- and two-coordinate coefficients (SNG-F18), making that unrestricted version much easier.

The prime lift adds an analytic hierarchy to these local questions. It does not add graph information: coefficients at prime powers recover the local coefficients, and local coefficients determine the Euler product. Its contribution is to turn a finite first discrepancy into a controlled singularity, allowing relational depth and arithmetic location to be studied together.

## References

[BHN1997] R. Bacher, P. de la Harpe and T. Nagnibeda, *The lattice of integral flows and the lattice of integral cuts on a finite graph*, Bulletin de la Societe Mathematique de France 125 (1997), 167-198. DOI: 10.24033/bsmf.2303.

[AM2009] D. Andren and K. Markstrom, *The bivariate Ising polynomial of a graph*, Discrete Applied Mathematics 157 (2009), 2515-2524. DOI: 10.1016/j.dam.2009.02.021.

[BPR2024] R. Bauerschmidt, J. Park and P.-F. Rodriguez, *The Discrete Gaussian model, I. Renormalisation group flow at high temperature*, Annals of Probability 52 (2024), no. 4, 1253-1359. DOI: 10.1214/23-AOP1658. arXiv:2202.02286.

[Moree2005] P. Moree, *The formal series Witt transform*, Discrete Mathematics 295 (2005), 143-160. DOI: 10.1016/j.disc.2005.03.004.
