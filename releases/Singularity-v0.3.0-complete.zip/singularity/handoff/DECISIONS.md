# Decision record

Append decisions with their mathematical or software reason, alternatives considered, evidence and consequences. Preserve prior entries unless correcting an explicit error. Do not store secrets or claim a decision was validated by a tool that did not run.

## D001: preserve the 36-push program

The original P01–P36 identifiers, scopes and dependencies remain the program. The later impact discussion supplies optional X01–X04 proposals. A formal roadmap change must record which acceptance obligations move or remain; renumbering silently makes old checkpoints unusable.

## D002: distinguish implementation from acceptance

Several planned outcomes are already partly or substantially implemented. Their dependency and validation criteria are not automatically complete. The status ledger therefore records existing evidence and exact gaps. Never use a percentage-complete estimate as a replacement for those gaps.

## D003: keep the working certificate format

The baseline format is singularity.certificate/1, implemented in certificates.py and used by retained packets. The roadmap's relational-height/1 was a proposed name. P03 must resolve its specification and compatibility explicitly; no automatic rename is authorized by a stale proposal.

## D004: release integrity means observed remote content

The first bootstrap README temporarily linked to files not yet published. The complete baseline was subsequently verified against GitHub's recursive tree, including all 86 blob hashes and all twelve README/monograph relative targets, and CI passed. Future publishing must verify the actual remote commit and referenced files before reporting completion. A local build or successful blob upload alone does not make a file reachable on main.

## D005: use portable session context

CLAUDE.md holds concise persistent project instructions. Detailed task packets, evidence, decisions and session logs remain ordinary versioned files. The handoff archive contains no service credentials, private account memory, cached conversation transcript or proprietary agent connection. This keeps the work usable by another competent development environment.

## D006: bound autonomous work by acceptance units

The initial prompt requests at most three accepted roadmap pushes, then a checkpoint. This bounds a session while respecting the user's authorization for implementation and ordinary commits/pushes. It does not require repeated permission for reversible routine choices. It does not install a recurring automation or an unlimited background agent.

## D007: singularity.certificate/1 satisfies P03's relational-height/1

P03's roadmap text named a format `relational-height/1`. The implemented, tested and retained format is `singularity.certificate/1`. P03 is accepted against the existing format; the roadmap identifier is amended to mean that format. No rename or migration was made, so all retained packets replay unchanged. Alternatives considered: (a) renaming, which would invalidate retained packets without a mathematical reason; (b) a second reader accepting both names, which would create two names for one schema. The reader rejects `relational-height/1` with an explicit superseded-name diagnostic rather than "unrecognized format", and the specification records the decision in `docs/specifications/COEFFICIENTS-v1.md`, section 9. A future incompatible change would be `singularity.certificate/2` with a checked migration.

## D008: session scope "build as much as you can"

On 2026-10-17 the user asked the session to "build as much as you can". This is read as the explicit scope override that CLAUDE.md permits for the three-push batch limit. Each push is still accepted only against its original criteria, committed separately where practical, and recorded in the ledger. The session remains bounded: no scheduler or unattended loop is installed, and it ends at a checkpoint.

## D009: formal pushes remain open without a proof-assistant toolchain

P07, and through it P08, P13, P14, P15, P33 and P34, need a kernel-checked development. In the 2026-10-17/18 session no Lean, Coq or Isabelle installation was present, and the environment's network policy returned HTTP 403 for the Lean release hosts, so no toolchain could be installed. Python tests and manuscript proofs are not substituted for the formal criterion. P07 stays `planned`, and the ledger records the blocker. The next session with a proof assistant should start with P07 as specified in its packet.

## D010: generated documents without XeLaTeX

`scripts/build_documents.py --no-pdf` regenerates `docs/MONOGRAPH.md`, `docs/monograph.tex`, `docs/monograph.html` and `results/manuscript_counts.json` with Pandoc, and leaves the PDFs unchanged. In this session the LaTeX/HTML/Markdown outputs were regenerated after every manuscript change. `output/pdf/monograph.pdf` and `output/pdf/visibility_paper.pdf` are therefore stale relative to the chapters until a build with XeLaTeX runs. The companion paper source did not change. The v0.1.0 release archive is historical and was not rebuilt.

## D011: a pinned core Lean toolchain from the GitHub release

On 2026-10-18 the network policy allowed GitHub release downloads, although the Lean release host still failed. The session downloaded `lean-4.12.0-linux.tar.zst` from `github.com/leanprover/lean4/releases`, unpacked it with the Python `zstandard` module in the scratch directory, and built `formal/` with core Lean only (no Mathlib, whose cache hosts were not used). CI repeats this in the `formal-lean` job and runs `scripts/check_formal.py`, which fails on any axiom outside `propext`, `Quot.sound` and `Classical.choice`. This supersedes the blocker in D009 for P07 and P08. Formal pushes that need Mathlib-scale libraries would require a further decision.

## D012: finish the original program with actual Mathlib analysis

On 2026-10-18 the owner explicitly requested "finish the remaining entirely". The remaining original units were P34-P36. The session preserved the existing research checkout and its history, fast-forwarded `main` to the already completed research branch, and completed the final units without changing their dependency gates. The optional `formal-analysis/` project pins Lean and Mathlib 4.12.0 and proves the actual positive-real visibility chain; the older core-only `RealFacts` theorem remains an explicitly abstract result. The two projects are independently buildable and their audits accept only standard Lean axioms. No numerical experiment or conditional premise packet substitutes for the real theorem. This supersedes the historical P34 partial checkpoint and the remaining analytic-library blocker in D011.

## D013: release two focused papers and preserve the research frontier

The v0.2.0 release contains the visibility paper and a second paper centered on the proved sharp observation budget for known-order simple 2-regular graphs. Each has a claim register, primary-literature comparison and reproducible inputs. Independent review checked the proof center and the achieved formal scope. This closes P35 and P36; it does not resolve fixed-pinning completeness, unrestricted efficient reconstruction or realization of the surviving interface ambiguities. Those remain explicit new research questions rather than hidden obligations or claims of this release. The complete archive is a plain `singularity/` source snapshot, with all three PDFs and pinned proof-source manifests; external Lean/Mathlib build caches and previous archives are excluded.

## D014: validate the completed PDF rather than the renderer exit code

Final release inspection caught a truncated monograph despite a successful XeLaTeX exit. The builder now writes XDV explicitly, invokes `xdvipdfmx` synchronously, and requires `pdfinfo` to parse the resulting PDF. It clears stale auxiliary files before its two passes. All final pages receive visual review, and the release receipt binds the reviewed PDF bytes and authored sources to their checks. Unsupported MathML macros and overflowing display/code layouts were corrected without changing mathematical statements; the chapter 12 certificate-scope sentence was narrowed to the explicitly named artifacts.

## D015: new identifiers for the operator and experiment program

On 2026-10-18 the owner asked to finish and release the operator checkpoint `21953a9` and then expand it. The P01–P36 ledger is complete and stays frozen; the P37–P72 file remains an idea pool. The new work is tracked as OE01–OE13 in `handoff/OPERATOR_LEDGER.md`. New manuscript results use SNG-O identifiers (Chapter 15), and examples continue the SNG-E series from E009. The working branch is `claude/exciting-brown-95vyq3`, which was merged with `main` at `21953a9`; `main` itself is updated only by the owner.
